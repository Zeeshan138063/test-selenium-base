# Desired capabilities example file for Sauce Labs
# Generate from https://saucelabs.com/products/platform-configurator
capabilities = {
    "browserName": "chrome",
    "browserVersion": "latest",
    "platformName": "macOS 10.14",
    "sauce:options": {},
}
