# from seleniumbase import BaseCase
# import pandas as pd
# import time
#
#
# class MouserScraper(BaseCase):
#     def test_scrape_products(self):
#         # Initialize lists to store product data
#         products = []
#
#         # Open the Mouser page
#         self.open("https://www.mouser.ca/c/tools-supplies/?m=Plato")
#
#         # Wait for the product table to load
#         self.wait_for_element("table#SearchResultsGrid_grid")
#
#         # Find all product rows
#         rows = self.find_elements("tr[data-index]")
#
#         for row in rows:
#             try:
#                 # Extract product data
#                 part_number = row.get_attribute("data-partnumber")
#                 mfr_number = row.get_attribute("data-mfrpartnumber")
#                 manufacturer = row.get_attribute("data-actualmfrname")
#
#                 # Find description within the row
#                 description = row.find_element("td.desc-column span").text
#
#                 # Find stock information
#                 stock_info = row.find_element("td span.available-amount").text
#                 stock_status = row.find_element("td span.avail-status").text
#
#                 # Find price (first price break)
#                 try:
#                     price = row.find_element("span[id^='lblPrice_']").text
#                 except:
#                     price = "N/A"
#
#                 # Find RoHS status
#                 try:
#                     rohs_btn = row.find_element("button.rohs-btn")
#                     rohs_status = rohs_btn.text
#                 except:
#                     rohs_status = "N/A"
#
#                 # Collect data in dictionary
#                 product_data = {
#                     'Mouser Part #': part_number,
#                     'Mfr. Part #': mfr_number,
#                     'Manufacturer': manufacturer,
#                     'Description': description,
#                     'Stock Quantity': stock_info,
#                     'Stock Status': stock_status,
#                     'Price': price,
#                     'RoHS Status': rohs_status
#                 }
#
#                 products.append(product_data)
#
#             except Exception as e:
#                 print(f"Error processing row: {e}")
#                 continue
#
#         # Convert to DataFrame
#         df = pd.DataFrame(products)
#
#         # Save to CSV
#         df.to_csv('mouser_products.csv', index=False)
#         print(f"Scraped {len(products)} products successfully")
#
#
# if __name__ == "__main__":
#     scraper = MouserScraper()
#     scraper.test_scrape_products()


from seleniumbase import BaseCase
from bs4 import BeautifulSoup
import pandas as pd
import time
import json
import re


class MouserScraper:
    def __init__(self, webdriver=None):
        """Initialize scraper with optional webdriver"""
        self.driver = webdriver
        self.base_url = "https://www.mouser.ca"
        self.products = []

    def parse_product_row(self, row):
        """Parse a single product row and extract data"""
        try:
            # Get base data from row attributes
            product = {
                'part_number': row.get('data-partnumber', ''),
                'mfr_part': row.get('data-mfrpartnumber', ''),
                'manufacturer': row.get('data-actualmfrname', '')
            }

            # Find description
            desc_cell = row.find('td', {'class': 'desc-column'})
            if desc_cell:
                product['description'] = desc_cell.get_text(strip=True)

            # Find stock info
            stock_cell = row.find('td', {'class': 'text-center'})
            if stock_cell:
                stock_qty = stock_cell.find('span', {'class': 'available-amount'})
                stock_status = stock_cell.find('span', {'class': 'avail-status'})
                product['stock_qty'] = stock_qty.text if stock_qty else ''
                product['stock_status'] = stock_status.text if stock_status else ''

            # Find price
            price_cell = row.find('span', id=re.compile(r'lblPrice_\d+_1'))
            if price_cell:
                product['price'] = price_cell.text.strip()
            else:
                product['price'] = ''

            # Find RoHS status
            rohs_btn = row.find('button', {'class': 'rohs-btn'})
            if rohs_btn:
                product['rohs_status'] = rohs_btn.text.strip()
            else:
                product['rohs_status'] = ''

            # Find datasheet link
            datasheet = row.find('a', id=re.compile(r'lnkDataSheet_\d+'))
            if datasheet and 'href' in datasheet.attrs:
                product['datasheet'] = datasheet['href']
            else:
                product['datasheet'] = ''

            return product

        except Exception as e:
            print(f"Error parsing row: {str(e)}")
            return None

    def extract_products_from_html(self, html):
        """Extract product data from HTML content"""
        soup = BeautifulSoup(html, 'html.parser')
        product_rows = soup.find_all('tr', attrs={'data-index': True})

        for row in product_rows:
            product = self.parse_product_row(row)
            if product:
                self.products.append(product)

    def scrape_product_page(self, url):
        """Scrape a single product page"""
        if not self.driver:
            raise Exception("WebDriver not initialized")

        try:
            self.driver.get(url)
            self.driver.wait_for_element("table#SearchResultsGrid_grid")
            time.sleep(2)  # Allow dynamic content to load

            # Get the page HTML after JavaScript execution
            page_html = self.driver.get_page_source()
            self.extract_products_from_html(page_html)

        except Exception as e:
            print(f"Error scraping page {url}: {str(e)}")

    def save_to_csv(self, filename):
        """Save scraped products to CSV file"""
        if not self.products:
            print("No products to save")
            return

        df = pd.DataFrame(self.products)
        df.to_csv(filename, index=False)
        print(f"Saved {len(self.products)} products to {filename}")

    def save_to_json(self, filename):
        """Save scraped products to JSON file"""
        if not self.products:
            print("No products to save")
            return

        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.products, f, indent=2)
        print(f"Saved {len(self.products)} products to {filename}")

class ScraperRunner(BaseCase):
    def test_run_scraper(self):
        scraper = MouserScraper(self)
        scraper.scrape_product_page("https://www.mouser.ca/c/tools-supplies/?m=Plato")
        scraper.save_to_csv("mouser_products.csv")
        scraper.save_to_json("mouser_products.json")
# Example usage
if __name__ == "__main__":



    runner = ScraperRunner()
    runner.test_run_scraper()