# # """Example of using CDP Mode without WebDriver"""
# # import asyncio
# # from seleniumbase import decorators
# # from seleniumbase.core import sb_cdp
# # from seleniumbase.undetected import cdp_driver
# #
# #
# # @decorators.print_runtime("CDP Priceline Example")
# # def main():
# #     url0 = "about:blank"  # Set Locale code from here first
# #     url1 = "https://canada.newark.com/w/search/prl/results?brand=general-devices&st=GENERAL-DEVICES"  # (The "real" URL)
# #     loop = asyncio.new_event_loop()
# #     driver = cdp_driver.cdp_util.start_sync()
# #     page = loop.run_until_complete(driver.get(url0))
# #     sb = sb_cdp.CDPMethods(loop, page, driver)
# #     sb.set_locale("en")  # This test expects English locale
# #     sb.open(url1)
# #     sb.sleep(2.5)
# #     sb.internalize_links()  # Don't open links in a new tab
# #     sb.click("#link_header_nav_experiences")
# #     sb.sleep(3.5)
# #     sb.remove_elements("msm-cookie-banner")
# #     sb.sleep(1.5)
# #     location = "Amsterdam"
# #     where_to = 'div[data-automation*="experiences"] input'
# #     button = 'button[data-automation*="experiences-search"]'
# #     sb.gui_click_element(where_to)
# #     sb.press_keys(where_to, location)
# #     sb.sleep(1)
# #     sb.gui_click_element(button)
# #     sb.sleep(3)
# #     print(sb.get_title())
# #     print("************")
# #     for i in range(8):
# #         sb.scroll_down(50)
# #         sb.sleep(0.2)
# #     cards = sb.select_all('h2[data-automation*="product-list-card"]')
# #     for card in cards:
# #         print("* %s" % card.text)
# #
# #
# # if __name__ == "__main__":
# #     main()
# from seleniumbase import Driver
# from selenium.webdriver.common.by import By
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# import pandas as pd
# import time
# import random
# from typing import List, Dict
# import logging
# from selenium.webdriver.chrome.options import Options
#
#
# class NewarkScraper:
#     def __init__(self):
#         self.setup_logging()
#         self.url = "https://canada.newark.com/w/search/prl/results?brand=general-devices&st=GENERAL-DEVICES"
#         self.driver = None
#
#     def setup_logging(self):
#         logging.basicConfig(
#             level=logging.INFO,
#             format='%(asctime)s - %(levelname)s - %(message)s',
#             handlers=[
#                 logging.FileHandler('newark_scraper.log'),
#                 logging.StreamHandler()
#             ]
#         )
#         self.logger = logging.getLogger(__name__)
#
#     def setup_driver(self):
#         """Initialize driver with stealth settings but without devtools"""
#         try:
#             # Create ChromeOptions
#             chrome_options = {
#                 "uc": True,  # Undetected ChromeDriver mode
#                 "headless": False,
#                 "block_images": True,
#                 "devtools": False,  # Disable devtools
#             }
#
#             self.driver = Driver(**chrome_options)
#
#             # Additional stealth settings
#             self.driver.execute_script("""
#                 Object.defineProperty(navigator, 'webdriver', {
#                     get: () => undefined
#                 });
#             """)
#
#             # Set CDP settings for stealth
#             self.driver.execute_cdp_cmd('Network.setUserAgentOverride', {
#                 "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
#                 "platform": "Windows",
#                 "mobile": False
#             })
#
#             self.logger.info("Driver setup completed successfully")
#             return True
#         except Exception as e:
#             self.logger.error(f"Failed to setup driver: {str(e)}")
#             return False
#
#     def add_random_delay(self, min_delay=2, max_delay=5):
#         """Add random delay between actions"""
#         time.sleep(random.uniform(min_delay, max_delay))
#
#     def extract_table_data(self) -> List[Dict]:
#         """Extract data from the product table"""
#         try:
#             # Wait for table to be present using a more reliable selector
#             WebDriverWait(self.driver, 20).until(
#                 EC.presence_of_element_located((By.CSS_SELECTOR, "table[class*='ProductListerTablestyles__Table']"))
#             )
#
#             # Get all rows using a more specific selector
#             rows = self.driver.find_elements(
#                 By.CSS_SELECTOR,
#                 "tr[class*='ProductListerTablestyles__TableRow']:not([class*='TableHeaderRow'])"
#             )
#
#             products_data = []
#             for row in rows:
#                 try:
#                     product = {
#                         'part_number': self._safe_extract(row,
#                                                           "div[class*='ManufacturerPartNoTableCellstyles__PartNumber']"),
#                         'order_code': self._safe_extract(row, "div[class*='OrderCodeTableCellstyles__OrderValue']"),
#                         'manufacturer': self._safe_extract(row,
#                                                            "div[class*='ProductDescriptionTableCellstyles__ProductValue']"),
#                         'availability': self._safe_extract(row,
#                                                            "div[class*='AvailabilityPrimaryStatusstyles__StatusMessage']"),
#                         'datasheet_url': self._get_datasheet_link(row),
#                         'prices': self._get_price_breaks(row),
#                         'pack_size': self._safe_extract(row, "div[class*='PriceForTableCellstyles__ProductValue']"),
#                     }
#
#                     # Extract extended attributes
#                     extended_attrs = {
#                         'enclosure_material': self._get_extended_attr(row, 'ads_f1000923'),
#                         'height_metric': self._get_extended_attr(row, 'adf_f1000911_bv'),
#                         'width_metric': self._get_extended_attr(row, 'adf_f1001323_bv'),
#                         'for_use_with': self._get_extended_attr(row, 'ads_f1001418_bv'),
#                         'height_imperial': self._get_extended_attr(row, 'adf_f1000626_bv'),
#                         'width_imperial': self._get_extended_attr(row, 'adf_f1000894_bv'),
#                         'product_range': self._get_extended_attr(row, 'ads_f1006816')
#                     }
#
#                     product.update(extended_attrs)
#                     products_data.append(product)
#
#                     # Add a small random delay between processing rows
#                     time.sleep(random.uniform(0.5, 1))
#
#                 except Exception as e:
#                     self.logger.error(f"Error processing row: {str(e)}")
#                     continue
#
#             return products_data
#
#         except Exception as e:
#             self.logger.error(f"Error extracting table data: {str(e)}")
#             return []
#
#     def _safe_extract(self, element, selector: str) -> str:
#         """Safely extract text from element"""
#         try:
#             el = element.find_element(By.CSS_SELECTOR, selector)
#             return el.text.strip() if el else ""
#         except:
#             return ""
#
#     def _get_datasheet_link(self, row) -> str:
#         """Extract datasheet URL"""
#         try:
#             datasheet_link = row.find_element(
#                 By.CSS_SELECTOR,
#                 "a[data-testid='catalog.listerTable.data-sheet__attachment-link']"
#             )
#             return datasheet_link.get_attribute('href')
#         except:
#             return ""
#
#     def _get_price_breaks(self, row) -> dict:
#         """Extract all price breaks"""
#         try:
#             price_breaks = {}
#             price_break_elements = row.find_elements(
#                 By.CSS_SELECTOR,
#                 "div[class*='PriceBreakupTableCellstyles__PriceBreak']"
#             )
#
#             for element in price_break_elements:
#                 try:
#                     # Extract quantity
#                     qty = element.find_element(
#                         By.CSS_SELECTOR,
#                         "span[class*='PriceBreakupTableCellstyles__BaseQuantity']"
#                     ).text.strip().replace("+", "")
#
#                     # Extract price
#                     price = element.find_element(
#                         By.CSS_SELECTOR,
#                         "span[class*='PriceBreakupTableCellstyles__MainPrice']"
#                     ).text.strip()
#
#                     price_breaks[qty] = price
#                 except:
#                     continue
#
#             return price_breaks
#         except:
#             return {}
#
#     def _get_extended_attr(self, row, attr_id: str) -> str:
#         """Extract extended attribute value"""
#         try:
#             # Find the cell containing the extended attribute
#             cell = row.find_element(
#                 By.CSS_SELECTOR,
#                 f"td[class*='extended-attribute--{attr_id}'] div.extended-attribute"
#             )
#             return cell.text.strip()
#         except:
#             return ""
#
#     def save_to_csv(self, data: List[Dict], filename: str = "newark_products.csv"):
#         """Save scraped data to CSV"""
#         try:
#             df = pd.DataFrame(data)
#             df.to_csv(filename, index=False)
#             self.logger.info(f"Data saved successfully to {filename}")
#
#             # Print preview of the data
#             self.logger.info("\nFirst few rows of scraped data:")
#             self.logger.info(df.head().to_string())
#
#         except Exception as e:
#             self.logger.error(f"Error saving data to CSV: {str(e)}")
#
#     def has_next_page(self) -> bool:
#         """Check if there is a next page"""
#         try:
#             # Look for the next page button
#             next_button = self.driver.find_element(
#                 By.CSS_SELECTOR,
#                 "button[aria-label='Next page']"
#             )
#             return not ('disabled' in next_button.get_attribute('class').split())
#         except:
#             return False
#
#     def go_to_next_page(self) -> bool:
#         """Navigate to the next page"""
#         try:
#             next_button = self.driver.find_element(
#                 By.CSS_SELECTOR,
#                 "button[aria-label='Next page']"
#             )
#             if not ('disabled' in next_button.get_attribute('class').split()):
#                 next_button.click()
#                 # Wait for table to refresh
#                 WebDriverWait(self.driver, 20).until(
#                     EC.presence_of_element_located((By.CSS_SELECTOR, "table[class*='ProductListerTablestyles__Table']"))
#                 )
#                 self.add_random_delay(2, 4)  # Add delay between page navigations
#                 return True
#             return False
#         except Exception as e:
#             self.logger.error(f"Error navigating to next page: {str(e)}")
#             return False
#
#     def run(self):
#         """Main scraping process with pagination"""
#         try:
#             if not self.setup_driver():
#                 return
#
#             self.logger.info("Starting scraping process...")
#             self.driver.get(self.url)
#
#             # Wait for initial page to load
#             self.add_random_delay(3, 5)
#
#             all_products_data = []
#             current_page = 1
#
#             while True:
#                 self.logger.info(f"Scraping page {current_page}")
#
#                 # Extract data from current page
#                 page_products = self.extract_table_data()
#                 if page_products:
#                     all_products_data.extend(page_products)
#                     self.logger.info(f"Found {len(page_products)} products on page {current_page}")
#
#                 # Check for next page
#                 if self.has_next_page():
#                     if not self.go_to_next_page():
#                         break
#                     current_page += 1
#                 else:
#                     break
#
#             # Save all collected data
#             if all_products_data:
#                 self.save_to_csv(all_products_data)
#                 self.logger.info(
#                     f"Successfully scraped total of {len(all_products_data)} products across {current_page} pages")
#             else:
#                 self.logger.warning("No products data was extracted")
#
#         except Exception as e:
#             self.logger.error(f"Scraping process failed: {str(e)}")
#         finally:
#             if self.driver:
#                 self.driver.quit()
#                 self.logger.info("Driver closed successfully")
#
#
# if __name__ == "__main__":
#     scraper = NewarkScraper()
#     scraper.run()

from seleniumbase import Driver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import time
import random
from typing import List, Dict
import logging
from selenium.webdriver.chrome.options import Options


class NewarkScraper:
    def __init__(self):
        self.setup_logging()
        self.url = "https://canada.newark.com/w/search/prl/results?brand=general-devices&st=GENERAL-DEVICES"
        self.driver = None

    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('newark_scraper.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def setup_driver(self):
        """Initialize driver with stealth settings but without devtools"""
        try:
            # Create ChromeOptions
            chrome_options = {
                "uc": True,  # Undetected ChromeDriver mode
                "headless": False,
                "block_images": True,
                "devtools": False,  # Disable devtools
            }

            self.driver = Driver(**chrome_options)

            # Additional stealth settings
            self.driver.execute_script("""
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                });
            """)

            # Set CDP settings for stealth
            self.driver.execute_cdp_cmd('Network.setUserAgentOverride', {
                "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "platform": "Windows",
                "mobile": False
            })

            self.logger.info("Driver setup completed successfully")
            return True
        except Exception as e:
            self.logger.error(f"Failed to setup driver: {str(e)}")
            return False

    def add_random_delay(self, min_delay=2, max_delay=5):
        """Add random delay between actions"""
        time.sleep(random.uniform(min_delay, max_delay))

    def extract_table_data(self) -> List[Dict]:
        """Extract data from the product table"""
        try:
            # Wait for table to be present using a more reliable selector
            WebDriverWait(self.driver, 20).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "table[class*='ProductListerTablestyles__Table']"))
            )

            # Get all rows using a more specific selector
            rows = self.driver.find_elements(
                By.CSS_SELECTOR,
                "tr[class*='ProductListerTablestyles__TableRow']:not([class*='TableHeaderRow'])"
            )

            products_data = []
            for row in rows:
                try:
                    product = {
                        'part_number': self._safe_extract(row,
                                                          "div[class*='ManufacturerPartNoTableCellstyles__PartNumber']"),
                        'order_code': self._safe_extract(row, "div[class*='OrderCodeTableCellstyles__OrderValue']"),
                        'manufacturer': self._safe_extract(row,
                                                           "div[class*='ProductDescriptionTableCellstyles__ProductValue']"),
                        'availability': self._safe_extract(row,
                                                           "div[class*='AvailabilityPrimaryStatusstyles__StatusMessage']"),
                        'datasheet_url': self._get_datasheet_link(row),
                        'prices': self._get_price_breaks(row),
                        'pack_size': self._safe_extract(row, "div[class*='PriceForTableCellstyles__ProductValue']"),
                    }

                    # Extract extended attributes
                    extended_attrs = {
                        'enclosure_material': self._get_extended_attr(row, 'ads_f1000923'),
                        'height_metric': self._get_extended_attr(row, 'adf_f1000911_bv'),
                        'width_metric': self._get_extended_attr(row, 'adf_f1001323_bv'),
                        'for_use_with': self._get_extended_attr(row, 'ads_f1001418_bv'),
                        'height_imperial': self._get_extended_attr(row, 'adf_f1000626_bv'),
                        'width_imperial': self._get_extended_attr(row, 'adf_f1000894_bv'),
                        'product_range': self._get_extended_attr(row, 'ads_f1006816')
                    }

                    product.update(extended_attrs)
                    products_data.append(product)

                    # Add a small random delay between processing rows
                    time.sleep(random.uniform(0.5, 1))

                except Exception as e:
                    self.logger.error(f"Error processing row: {str(e)}")
                    continue

            return products_data

        except Exception as e:
            self.logger.error(f"Error extracting table data: {str(e)}")
            return []

    def _safe_extract(self, element, selector: str) -> str:
        """Safely extract text from element"""
        try:
            el = element.find_element(By.CSS_SELECTOR, selector)
            return el.text.strip() if el else ""
        except:
            return ""

    def _get_datasheet_link(self, row) -> str:
        """Extract datasheet URL"""
        try:
            datasheet_link = row.find_element(
                By.CSS_SELECTOR,
                "a[data-testid='catalog.listerTable.data-sheet__attachment-link']"
            )
            return datasheet_link.get_attribute('href')
        except:
            return ""

    def _get_price_breaks(self, row) -> dict:
        """Extract all price breaks"""
        try:
            price_breaks = {}
            price_break_elements = row.find_elements(
                By.CSS_SELECTOR,
                "div[class*='PriceBreakupTableCellstyles__PriceBreak']"
            )

            for element in price_break_elements:
                try:
                    # Extract quantity
                    qty = element.find_element(
                        By.CSS_SELECTOR,
                        "span[class*='PriceBreakupTableCellstyles__BaseQuantity']"
                    ).text.strip().replace("+", "")

                    # Extract price
                    price = element.find_element(
                        By.CSS_SELECTOR,
                        "span[class*='PriceBreakupTableCellstyles__MainPrice']"
                    ).text.strip()

                    price_breaks[qty] = price
                except:
                    continue

            return price_breaks
        except:
            return {}

    def _get_extended_attr(self, row, attr_id: str) -> str:
        """Extract extended attribute value"""
        try:
            # Find the cell containing the extended attribute
            cell = row.find_element(
                By.CSS_SELECTOR,
                f"td[class*='extended-attribute--{attr_id}'] div.extended-attribute"
            )
            return cell.text.strip()
        except:
            return ""

    def save_to_csv(self, data: List[Dict], filename: str = "newark_products.csv"):
        """Save scraped data to CSV"""
        try:
            df = pd.DataFrame(data)
            df.to_csv(filename, index=False)
            self.logger.info(f"Data saved successfully to {filename}")

            # Print preview of the data
            self.logger.info("\nFirst few rows of scraped data:")
            self.logger.info(df.head().to_string())

        except Exception as e:
            self.logger.error(f"Error saving data to CSV: {str(e)}")

    def has_next_page(self) -> bool:
        """Check if there is a next page"""
        try:
            # Look for the next page button with specific class
            next_button = self.driver.find_element(
                By.CSS_SELECTOR,
                "button.bx--pagination__button--forward:not(.bx--pagination__button--no-index)"
            )
            # Check if button is disabled
            return not ('bx--pagination__button--disabled' in next_button.get_attribute('class').split())
        except Exception as e:
            self.logger.debug(f"No next page button found: {str(e)}")
            return False

    def go_to_next_page(self) -> bool:
        """Navigate to the next page"""
        try:
            # Find the next button with the exact classes
            next_button = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((
                    By.CSS_SELECTOR,
                    "button.bx--pagination__button--forward:not(.bx--pagination__button--no-index)"
                ))
            )

            if not ('bx--pagination__button--disabled' in next_button.get_attribute('class').split()):
                # Scroll button into view
                self.driver.execute_script("arguments[0].scrollIntoView(true);", next_button)

                # Add a small delay before clicking
                time.sleep(random.uniform(0.5, 1))

                # Click using JavaScript for better reliability
                self.driver.execute_script("arguments[0].click();", next_button)

                # Wait for table to refresh
                WebDriverWait(self.driver, 20).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, "table[class*='ProductListerTablestyles__Table']"))
                )
                self.add_random_delay(2, 4)  # Add delay between page navigations
                return True
            return False
        except Exception as e:
            self.logger.error(f"Error navigating to next page: {str(e)}")
            return False

    def run(self):
        """Main scraping process with pagination"""
        try:
            if not self.setup_driver():
                return

            self.logger.info("Starting scraping process...")
            self.driver.get(self.url)

            # Wait for initial page to load
            WebDriverWait(self.driver, 20).until(
                EC.presence_of_element_located((
                    By.CSS_SELECTOR,
                    "table[class*='ProductListerTablestyles__Table']"
                ))
            )
            self.add_random_delay(3, 5)

            all_products_data = []
            current_page = 1

            while True:
                self.logger.info(f"Scraping page {current_page}")

                # Extract data from current page
                page_products = self.extract_table_data()
                if page_products:
                    all_products_data.extend(page_products)
                    self.logger.info(f"Found {len(page_products)} products on page {current_page}")

                # Check for next page
                if self.has_next_page():
                    if not self.go_to_next_page():
                        break
                    current_page += 1
                else:
                    break

            # Save all collected data
            if all_products_data:
                self.save_to_csv(all_products_data)
                self.logger.info(
                    f"Successfully scraped total of {len(all_products_data)} products across {current_page} pages")
            else:
                self.logger.warning("No products data was extracted")

        except Exception as e:
            self.logger.error(f"Scraping process failed: {str(e)}")
        finally:
            if self.driver:
                self.driver.quit()
                self.logger.info("Driver closed successfully")


if __name__ == "__main__":
    scraper = NewarkScraper()
    scraper.run()