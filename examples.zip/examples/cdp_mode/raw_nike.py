# # # from seleniumbase import SB
# # #
# # # # with SB(uc=True, test=True, locale_code="en", ad_block=True) as sb:
# # # #     url = "https://www.nike.com/"
# # # #     sb.activate_cdp_mode(url)
# # # #     sb.sleep(2.5)
# # # #     sb.cdp.gui_click_element('div[data-testid="user-tools-container"]')
# # # #     sb.sleep(1.5)
# # # #     search = "Nike Air Force 1"
# # # #     sb.cdp.press_keys('input[type="search"]', search)
# # # #     sb.sleep(4)
# # # #     elements = sb.cdp.select_all('ul[data-testid*="products"] figure .details')
# # # #     if elements:
# # # #         print('**** Found results for "%s": ****' % search)
# # # #     for element in elements:
# # # #         print("* " + element.text)
# # # #     sb.sleep(2)
# # #
# # #
# # #
# # # with SB(uc=True, test=True, locale_code="en", ad_block=True) as sb:
# # #     url = "https://canada.newark.com/w/search/prl/results?brand=general-devices&st=GENERAL-DEVICES"
# # #     sb.activate_cdp_mode(url)
# # #     sb.sleep(2.5)
# # #     sb.cdp.gui_click_element('div#main > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(2) > div:nth-of-type(2)')
# # #     sb.sleep(1.5)
# # #     search = "Nike Air Force 1"
# # #     sb.cdp.press_keys('input[type="search"]', search)
# # #     sb.sleep(4)
# # #     elements = sb.cdp.select_all('ul[data-testid*="products"] figure .details')
# # #     if elements:
# # #         print('**** Found results for "%s": ****' % search)
# # #     for element in elements:
# # #         print("* " + element.text)
# # #     sb.sleep(2)
# # #
# # #  #
# # #  #
# # #  # self.activate_cdp_mode()
# # #  #        self.open("https://canada.newark.com/w/search/prl/results?brand=general-devices&st=GENERAL-DEVICES")
# # #  #        self.click("div#main > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(2) > div:nth-of-type(2)")
# # #  #        self.click("div#main > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(2) > div:nth-of-type(2) > div > div:nth-of-type(2) > div:nth-of-type(2)")
# # #  #        self.click('svg[aria-label="Next Page"]')
# # #  #        self.click('div[data-testid="catalog.listerTable.table-cell__information-label"]')
# # #  #        self.click('svg[aria-label="Next Page"] path')
# # #  #        self.click('button:contains("Next Page")')
# #
# #
# # from seleniumbase import Driver
# # from selenium.webdriver.common.by import By
# # from selenium.webdriver.support.ui import WebDriverWait
# # from selenium.webdriver.support import expected_conditions as EC
# # import pandas as pd
# # import time
# # import random
# # from typing import List, Dict
# # import logging
# #
# #
# # class NewarkScraper:
# #     def __init__(self):
# #         self.setup_logging()
# #         self.url = "https://canada.newark.com/w/search/prl/results?brand=general-devices&st=GENERAL-DEVICES"
# #         self.driver = None
# #
# #     def setup_logging(self):
# #         logging.basicConfig(
# #             level=logging.INFO,
# #             format='%(asctime)s - %(levelname)s - %(message)s',
# #             handlers=[
# #                 logging.FileHandler('newark_scraper.log'),
# #                 logging.StreamHandler()
# #             ]
# #         )
# #         self.logger = logging.getLogger(__name__)
# #
# #     def setup_driver(self):
# #         """Initialize driver with CDP and stealth settings"""
# #         try:
# #             options = {
# #                 "devtools": True,
# #                 "uc": True,  # Undetected ChromeDriver mode
# #                 "headless": False,  # Set to True for production
# #                 "block_images": True,  # Speeds up loading
# #             }
# #
# #             self.driver = Driver(**options)
# #
# #             # Set CDP settings for stealth
# #             cdp_settings = {
# #                 "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
# #                 "platform": "Windows",
# #                 "mobile": False
# #             }
# #
# #             self.driver.execute_cdp_cmd('Network.setUserAgentOverride', cdp_settings)
# #
# #             # Disable WebDriver flags
# #             self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
# #
# #             self.logger.info("Driver setup completed successfully")
# #             return True
# #         except Exception as e:
# #             self.logger.error(f"Failed to setup driver: {str(e)}")
# #             return False
# #
# #     def add_random_delay(self, min_delay=2, max_delay=5):
# #         """Add random delay between actions to appear more human-like"""
# #         time.sleep(random.uniform(min_delay, max_delay))
# #
# #     def extract_table_data(self) -> List[Dict]:
# #         """Extract data from the product table"""
# #         try:
# #             # Wait for table body to be present using a partial class name
# #             table_body = WebDriverWait(self.driver, 20).until(
# #                 EC.presence_of_element_located((By.CSS_SELECTOR, "[class*='ProductListerTablestyles__TableBody-']"))
# #             )
# #
# #             # Get all rows
# #             rows = table_body.find_elements(By.CSS_SELECTOR, "[class*='ProductListerTablestyles__TableRow-']")
# #
# #             products_data = []
# #             for row in rows:
# #                 try:
# #                     product = {
# #                         'name': self._safe_extract(row, "[class*='ProductListerTablestyles__ProductName-']"),
# #                         'manufacturer': self._safe_extract(row, "[class*='ProductListerTablestyles__Manufacturer-']"),
# #                         'part_number': self._safe_extract(row, "[class*='ProductListerTablestyles__PartNumber-']"),
# #                         'price': self._safe_extract(row, "[class*='ProductListerTablestyles__Price-']"),
# #                         'stock': self._safe_extract(row, "[class*='ProductListerTablestyles__Stock-']")
# #                     }
# #                     products_data.append(product)
# #                     self.add_random_delay(1, 2)  # Short delay between rows
# #                 except Exception as e:
# #                     self.logger.error(f"Error extracting row data: {str(e)}")
# #                     continue
# #
# #             return products_data
# #         except Exception as e:
# #             self.logger.error(f"Error extracting table data: {str(e)}")
# #             return []
# #
# #     def _safe_extract(self, element, selector: str) -> str:
# #         """Safely extract text from element"""
# #         try:
# #             return element.find_element(By.CSS_SELECTOR, selector).text.strip()
# #         except:
# #             return ""
# #
# #     def save_to_csv(self, data: List[Dict], filename: str = "newark_products.csv"):
# #         """Save scraped data to CSV"""
# #         try:
# #             df = pd.DataFrame(data)
# #             df.to_csv(filename, index=False)
# #             self.logger.info(f"Data saved successfully to {filename}")
# #         except Exception as e:
# #             self.logger.error(f"Error saving data to CSV: {str(e)}")
# #
# #     def run(self):
# #         """Main scraping process"""
# #         try:
# #             if not self.setup_driver():
# #                 return
# #
# #             self.logger.info("Starting scraping process")
# #             self.driver.get(self.url)
# #             self.add_random_delay()  # Random delay after page load
# #
# #             products_data = self.extract_table_data()
# #
# #             if products_data:
# #                 self.save_to_csv(products_data)
# #                 self.logger.info(f"Successfully scraped {len(products_data)} products")
# #             else:
# #                 self.logger.warning("No products data was extracted")
# #
# #         except Exception as e:
# #             self.logger.error(f"Scraping process failed: {str(e)}")
# #         finally:
# #             if self.driver:
# #                 self.driver.quit()
# #                 self.logger.info("Driver closed successfully")
# #
# #
# # if __name__ == "__main__":
# #     scraper = NewarkScraper()
# #     scraper.run()
#
#
# from seleniumbase import Driver
# from selenium.webdriver.common.by import By
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# import pandas as pd
# import time
# import random
# from typing import List, Dict
# import logging
# from selenium.webdriver.chrome.options import Options
#
#
# class NewarkScraper:
#     def __init__(self):
#         self.setup_logging()
#         self.url = "https://canada.newark.com/w/search/prl/results?brand=general-devices&st=GENERAL-DEVICES"
#         self.driver = None
#
#     def setup_logging(self):
#         logging.basicConfig(
#             level=logging.INFO,
#             format='%(asctime)s - %(levelname)s - %(message)s',
#             handlers=[
#                 logging.FileHandler('newark_scraper.log'),
#                 logging.StreamHandler()
#             ]
#         )
#         self.logger = logging.getLogger(__name__)
#
#     def setup_driver(self):
#         """Initialize driver with stealth settings but without devtools"""
#         try:
#             # Create ChromeOptions
#             chrome_options = {
#                 "uc": True,  # Undetected ChromeDriver mode
#                 "headless": False,
#                 "block_images": True,
#                 "devtools": False,  # Disable devtools
#             }
#
#             self.driver = Driver(**chrome_options)
#
#             # Additional stealth settings
#             self.driver.execute_script("""
#                 Object.defineProperty(navigator, 'webdriver', {
#                     get: () => undefined
#                 });
#             """)
#
#             # Set CDP settings for stealth
#             self.driver.execute_cdp_cmd('Network.setUserAgentOverride', {
#                 "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
#                 "platform": "Windows",
#                 "mobile": False
#             })
#
#             self.logger.info("Driver setup completed successfully")
#             return True
#         except Exception as e:
#             self.logger.error(f"Failed to setup driver: {str(e)}")
#             return False
#
#     def add_random_delay(self, min_delay=2, max_delay=5):
#         """Add random delay between actions"""
#         time.sleep(random.uniform(min_delay, max_delay))
#
#     def extract_table_data(self) -> List[Dict]:
#         """Extract data from the product table"""
#         try:
#             # Wait for table to be present using a more reliable selector
#             WebDriverWait(self.driver, 20).until(
#                 EC.presence_of_element_located((By.CSS_SELECTOR, "table[class*='ProductListerTablestyles__Table']"))
#             )
#
#             # Get all rows using a more specific selector
#             rows = self.driver.find_elements(
#                 By.CSS_SELECTOR,
#                 "tr[class*='ProductListerTablestyles__TableRow']:not([class*='TableHeaderRow'])"
#             )
#
#             products_data = []
#             for row in rows:
#                 try:
#                     product = {
#                         'part_number': self._safe_extract(row,
#                                                           "div[class*='ManufacturerPartNoTableCellstyles__PartNumber']"),
#                         'order_code': self._safe_extract(row, "div[class*='OrderCodeTableCellstyles__OrderValue']"),
#                         'manufacturer': self._safe_extract(row,
#                                                            "div[class*='ProductDescriptionTableCellstyles__ProductValue']"),
#                         'availability': self._safe_extract(row,
#                                                            "div[class*='AvailabilityPrimaryStatusstyles__StatusMessage']"),
#                         'price': self._safe_extract(row, "span[class*='PriceBreakupTableCellstyles__MainPrice']"),
#                         'pack_size': self._safe_extract(row, "div[class*='PriceForTableCellstyles__ProductValue']"),
#                     }
#
#                     # Extract extended attributes
#                     extended_attrs = {
#                         'enclosure_material': self._get_extended_attr(row, 'ads_f1000923'),
#                         'height_metric': self._get_extended_attr(row, 'adf_f1000911_bv'),
#                         'width_metric': self._get_extended_attr(row, 'adf_f1001323_bv'),
#                         'for_use_with': self._get_extended_attr(row, 'ads_f1001418_bv'),
#                         'height_imperial': self._get_extended_attr(row, 'adf_f1000626_bv'),
#                         'width_imperial': self._get_extended_attr(row, 'adf_f1000894_bv'),
#                         'product_range': self._get_extended_attr(row, 'ads_f1006816')
#                     }
#
#                     product.update(extended_attrs)
#                     products_data.append(product)
#
#                     # Add a small random delay between processing rows
#                     time.sleep(random.uniform(0.5, 1))
#
#                 except Exception as e:
#                     self.logger.error(f"Error processing row: {str(e)}")
#                     continue
#
#             return products_data
#
#         except Exception as e:
#             self.logger.error(f"Error extracting table data: {str(e)}")
#             return []
#
#     def _safe_extract(self, element, selector: str) -> str:
#         """Safely extract text from element"""
#         try:
#             el = element.find_element(By.CSS_SELECTOR, selector)
#             return el.text.strip() if el else ""
#         except:
#             return ""
#
#     def _get_extended_attr(self, row, attr_id: str) -> str:
#         """Extract extended attribute value"""
#         try:
#             # Find the cell containing the extended attribute
#             cell = row.find_element(
#                 By.CSS_SELECTOR,
#                 f"td[class*='extended-attribute--{attr_id}'] div.extended-attribute"
#             )
#             return cell.text.strip()
#         except:
#             return ""
#
#     def save_to_csv(self, data: List[Dict], filename: str = "newark_products.csv"):
#         """Save scraped data to CSV"""
#         try:
#             df = pd.DataFrame(data)
#             df.to_csv(filename, index=False)
#             self.logger.info(f"Data saved successfully to {filename}")
#
#             # Print preview of the data
#             self.logger.info("\nFirst few rows of scraped data:")
#             self.logger.info(df.head().to_string())
#
#         except Exception as e:
#             self.logger.error(f"Error saving data to CSV: {str(e)}")
#
#     def run(self):
#         """Main scraping process"""
#         try:
#             if not self.setup_driver():
#                 return
#
#             self.logger.info("Starting scraping process...")
#             self.driver.get(self.url)
#
#             # Wait for page to load
#             self.add_random_delay(3, 5)
#
#             products_data = self.extract_table_data()
#
#             if products_data:
#                 self.save_to_csv(products_data)
#                 self.logger.info(f"Successfully scraped {len(products_data)} products")
#             else:
#                 self.logger.warning("No products data was extracted")
#
#         except Exception as e:
#             self.logger.error(f"Scraping process failed: {str(e)}")
#         finally:
#             if self.driver:
#                 self.driver.quit()
#                 self.logger.info("Driver closed successfully")
#
#
# if __name__ == "__main__":
#     scraper = NewarkScraper()
#     scraper.run()

<<<<<<< Updated upstream
with SB(uc=True, test=True, locale="en", pls="none") as sb:
    url = "https://www.nike.com/"
    sb.activate_cdp_mode(url)
    sb.sleep(2.5)
    sb.cdp.click('div[data-testid="user-tools-container"]')
    sb.sleep(1.5)
    search = "Nike Air Force 1"
    sb.cdp.press_keys('input[type="search"]', search)
    sb.sleep(4)
    elements = sb.cdp.select_all('ul[data-testid*="products"] figure .details')
    if elements:
        print('**** Found results for "%s": ****' % search)
    for element in elements:
        print("* " + element.text)
    sb.sleep(2)
=======
from seleniumbase import Driver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import time
import random
from typing import List, Dict
import logging
from selenium.webdriver.chrome.options import Options


class NewarkScraper:
    def __init__(self):
        self.setup_logging()
        self.url = "https://canada.newark.com/w/search/prl/results?brand=general-devices&st=GENERAL-DEVICES"
        self.driver = None

    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('newark_scraper.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def setup_driver(self):
        """Initialize driver with stealth settings but without devtools"""
        try:
            # Create ChromeOptions
            chrome_options = {
                "uc": True,  # Undetected ChromeDriver mode
                "headless": False,
                "block_images": True,
                "devtools": False,  # Disable devtools
            }

            self.driver = Driver(**chrome_options)

            # Additional stealth settings
            self.driver.execute_script("""
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined
                });
            """)

            # Set CDP settings for stealth
            self.driver.execute_cdp_cmd('Network.setUserAgentOverride', {
                "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "platform": "Windows",
                "mobile": False
            })

            self.logger.info("Driver setup completed successfully")
            return True
        except Exception as e:
            self.logger.error(f"Failed to setup driver: {str(e)}")
            return False

    def add_random_delay(self, min_delay=2, max_delay=5):
        """Add random delay between actions"""
        time.sleep(random.uniform(min_delay, max_delay))

    def extract_table_data(self) -> List[Dict]:
        """Extract data from the product table"""
        try:
            # Wait for table to be present using a more reliable selector
            WebDriverWait(self.driver, 20).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, "table[class*='ProductListerTablestyles__Table']"))
            )

            # Get all rows using a more specific selector
            rows = self.driver.find_elements(
                By.CSS_SELECTOR,
                "tr[class*='ProductListerTablestyles__TableRow']:not([class*='TableHeaderRow'])"
            )

            products_data = []
            for row in rows:
                try:
                    product = {
                        'part_number': self._safe_extract(row,
                                                          "div[class*='ManufacturerPartNoTableCellstyles__PartNumber']"),
                        'order_code': self._safe_extract(row, "div[class*='OrderCodeTableCellstyles__OrderValue']"),
                        'manufacturer': self._safe_extract(row,
                                                           "div[class*='ProductDescriptionTableCellstyles__ProductValue']"),
                        'availability': self._safe_extract(row,
                                                           "div[class*='AvailabilityPrimaryStatusstyles__StatusMessage']"),
                        'datasheet_url': self._get_datasheet_link(row),
                        'prices': self._get_price_breaks(row),
                        'pack_size': self._safe_extract(row, "div[class*='PriceForTableCellstyles__ProductValue']"),
                    }

                    # Extract extended attributes
                    extended_attrs = {
                        'enclosure_material': self._get_extended_attr(row, 'ads_f1000923'),
                        'height_metric': self._get_extended_attr(row, 'adf_f1000911_bv'),
                        'width_metric': self._get_extended_attr(row, 'adf_f1001323_bv'),
                        'for_use_with': self._get_extended_attr(row, 'ads_f1001418_bv'),
                        'height_imperial': self._get_extended_attr(row, 'adf_f1000626_bv'),
                        'width_imperial': self._get_extended_attr(row, 'adf_f1000894_bv'),
                        'product_range': self._get_extended_attr(row, 'ads_f1006816')
                    }

                    product.update(extended_attrs)
                    products_data.append(product)

                    # Add a small random delay between processing rows
                    time.sleep(random.uniform(0.5, 1))

                except Exception as e:
                    self.logger.error(f"Error processing row: {str(e)}")
                    continue

            return products_data

        except Exception as e:
            self.logger.error(f"Error extracting table data: {str(e)}")
            return []

    def _safe_extract(self, element, selector: str) -> str:
        """Safely extract text from element"""
        try:
            el = element.find_element(By.CSS_SELECTOR, selector)
            return el.text.strip() if el else ""
        except:
            return ""

    def _get_datasheet_link(self, row) -> str:
        """Extract datasheet URL"""
        try:
            datasheet_link = row.find_element(
                By.CSS_SELECTOR,
                "a[data-testid='catalog.listerTable.data-sheet__attachment-link']"
            )
            return datasheet_link.get_attribute('href')
        except:
            return ""

    def _get_price_breaks(self, row) -> dict:
        """Extract all price breaks"""
        try:
            price_breaks = {}
            price_break_elements = row.find_elements(
                By.CSS_SELECTOR,
                "div[class*='PriceBreakupTableCellstyles__PriceBreak']"
            )

            for element in price_break_elements:
                try:
                    # Extract quantity
                    qty = element.find_element(
                        By.CSS_SELECTOR,
                        "span[class*='PriceBreakupTableCellstyles__BaseQuantity']"
                    ).text.strip().replace("+", "")

                    # Extract price
                    price = element.find_element(
                        By.CSS_SELECTOR,
                        "span[class*='PriceBreakupTableCellstyles__MainPrice']"
                    ).text.strip()

                    price_breaks[qty] = price
                except:
                    continue

            return price_breaks
        except:
            return {}

    def _get_extended_attr(self, row, attr_id: str) -> str:
        """Extract extended attribute value"""
        try:
            # Find the cell containing the extended attribute
            cell = row.find_element(
                By.CSS_SELECTOR,
                f"td[class*='extended-attribute--{attr_id}'] div.extended-attribute"
            )
            return cell.text.strip()
        except:
            return ""

    def save_to_csv(self, data: List[Dict], filename: str = "newark_products.csv"):
        """Save scraped data to CSV"""
        try:
            df = pd.DataFrame(data)
            df.to_csv(filename, index=False)
            self.logger.info(f"Data saved successfully to {filename}")

            # Print preview of the data
            self.logger.info("\nFirst few rows of scraped data:")
            self.logger.info(df.head().to_string())

        except Exception as e:
            self.logger.error(f"Error saving data to CSV: {str(e)}")

    def run(self):
        """Main scraping process"""
        try:
            if not self.setup_driver():
                return

            self.logger.info("Starting scraping process...")
            self.driver.get(self.url)

            # Wait for page to load
            self.add_random_delay(3, 5)

            products_data = self.extract_table_data()

            if products_data:
                self.save_to_csv(products_data)
                self.logger.info(f"Successfully scraped {len(products_data)} products")
            else:
                self.logger.warning("No products data was extracted")

        except Exception as e:
            self.logger.error(f"Scraping process failed: {str(e)}")
        finally:
            if self.driver:
                self.driver.quit()
                self.logger.info("Driver closed successfully")


if __name__ == "__main__":
    scraper = NewarkScraper()
    scraper.run()
>>>>>>> Stashed changes
