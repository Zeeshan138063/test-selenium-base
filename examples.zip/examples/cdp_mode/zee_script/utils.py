import random
import string

import random
import names


def generate_email(domain=None):
    first_name = names.get_first_name().lower()
    last_name = names.get_last_name().lower()

    email_patterns = [
        f"{first_name}.{last_name}",
        f"{first_name}{last_name}",
        f"{first_name[0]}{last_name}",
        f"{first_name}{last_name[0]}",
        f"{first_name}{random.randint(1, 99)}"
    ]

    domains = [
        "gmail.com",
        "outlook.com",
        "yahoo.com",
        "hotmail.com",
        "icloud.com",
        "protonmail.com"
    ]

    username = random.choice(email_patterns)
    email_domain = domain if domain else random.choice(domains)

    return f"{username}@{email_domain}"

# Examples a
# email = generate_email()  # default domain
# email = generate_email("gmail.com")  # custom domain


import random
import string


def generate_password(length=12):
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    special = "!@#$%^&*"

    # Ensure at least one character from each category
    password = [
        random.choice(lowercase),
        random.choice(uppercase),
        random.choice(digits),
        random.choice(special)
    ]

    # Fill remaining length with random characters
    all_chars = lowercase + uppercase + digits + special
    password.extend(random.choice(all_chars) for _ in range(length - 4))

    # Shuffle the password
    random.shuffle(password)

    return ''.join(password)


# Usage
# password = generate_password()
# password = generate_password(16)