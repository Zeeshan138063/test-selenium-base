#                     self.logger.error(f"Error processing row: {str(e)}")

from seleniumbase import Driver,SB
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import time
import random
from typing import List, Dict
import logging
from selenium.webdriver.chrome.options import Options


class FragranceBy:
    def __init__(self):
        self.setup_logging()
        self.url = "https://fragrancebuy.ca/products/24faubourg-woman"
        self.driver = None

    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('newark_scraper.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def setup_driver(self):
        """Initialize driver with stealth settings but without devtools"""
        try:
            # Create ChromeOptions
            chrome_options = {
                "uc": True,  # Undetected ChromeDriver mode
                "headless": False,
                "block_images": True,
                "incognito": True,  # Incognito mode

                "devtools": False,  # Disable devtools
            }

            # self.driver = Driver(**chrome_options)
            with SB(uc=True, test=True, locale_code="en") as sb:
                sb.activate_cdp_mode(self.url)
                sb.sleep(2)
                sb.uc_gui_click_captcha()  # PyAutoGUI click. (Linux needs it)
                sb.sleep(2)
            # sb.activate_cdp_mode(url)
            # sb.sleep(2)
            # sb.uc_gui_click_captcha()
            self.logger.info("Driver setup completed successfully")
            return True
        except Exception as e:
            self.logger.error(f"Failed to setup driver: {str(e)}")
            return False

    def add_random_delay(self, min_delay=2, max_delay=5):
        """Add random delay between actions"""
        time.sleep(random.uniform(min_delay, max_delay))

    def run(self):
        """Main scraping process with pagination"""
        try:
            if not self.setup_driver():
                return

            self.logger.info("Starting scraping process...")
            self.driver.get(self.url)

            # Wait for initial page to load
            WebDriverWait(self.driver, 20).until(
                EC.presence_of_element_located((
                    By.CSS_SELECTOR,
                    "table[class*='ProductListerTablestyles__Table']"
                ))
            )
            self.add_random_delay(3, 5)

            all_products_data = []
            current_page = 1

            while True:
                self.logger.info(f"Scraping page {current_page}")

                # Extract data from current page
                page_products = self.extract_table_data()
                if page_products:
                    all_products_data.extend(page_products)
                    self.logger.info(f"Found {len(page_products)} products on page {current_page}")

                # Check for next page
                if self.has_next_page():
                    if not self.go_to_next_page():
                        break
                    current_page += 1
                else:
                    break

            # Save all collected data
            if all_products_data:
                self.save_to_csv(all_products_data)
                self.logger.info(
                    f"Successfully scraped total of {len(all_products_data)} products across {current_page} pages")
            else:
                self.logger.warning("No products data was extracted")

        except Exception as e:
            self.logger.error(f"Scraping process failed: {str(e)}")
        finally:
            if self.driver:
                self.driver.quit()
                self.logger.info("Driver closed successfully")


if __name__ == "__main__":
    scraper = FragranceBy()
    scraper.run()