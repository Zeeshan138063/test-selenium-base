import pyperclip
from seleniumbase import SB
from utils import generate_email, generate_password
# with SB(uc=True, test=True, locale_code="en", ad_block=True) as sb:
#     url = "https://app.tavily.com/home"
#     sb.activate_cdp_mode(url)
#     sb.sleep(20)
#
#     sb.cdp.click('[href*="/u/signup/"]')
#
#     sb.sleep(4)
#     _email =  generate_email("gmail.com")
#     sb.cdp.type("#email",_email)
#     sb.sleep(4)
#     # type = "submit"
#     sb.cdp.click("button[type='submit']")
#     sb.sleep(4)
#     _password =  generate_password(20)
#     sb.cdp.type("#password",_password)
#     sb.sleep(10)
#
#     sb.cdp.click("button[type='submit']")
#     sb.sleep(60)
#     # tvly - ATUktWWJkjBq6Dam5NA0n2CPEK6vZiIU
#     sb.cdp.click("input[type='text']")
#     sb.sleep(10)
# #     clipboard_content = pyperclip.paste()
# #     # now store the email address, password and the clipboard content in a file
# #     with open('credentials.txt', 'w') as f:
# #         f.write(f"Email: {_email}\n")
# #         f.write(f"Password: {_password}\n")
# #         f.write(f"Clipboard: {clipboard_content}\n")
# 
# 
# import pyperclip
# from seleniumbase import SB
# from utils import generate_email, generate_password
# import pandas as pd
# from datetime import datetime
# import time
# import logging
# 
# # Configure logging
# logging.basicConfig(filename='automation.log', level=logging.INFO)
# 
# 
# def save_to_excel(data_list, filename='credentials.xlsx'):
#     try:
#         df = pd.DataFrame(data_list)
#         df.to_excel(filename, index=False)
#         logging.info(f"Data saved to {filename}")
#     except Exception as e:
#         logging.error(f"Error saving to Excel: {e}")
# 
# 
# def automate_signup(num_iterations=5, delay_between=60):
#     data_list = []
# 
#     for i in range(num_iterations):
#         try:
#             with SB(uc=True, test=True, locale_code="en", ad_block=True) as sb:
#                 url = "https://app.tavily.com/home"
#                 sb.activate_cdp_mode(url)
#                 sb.sleep(20)
# 
#                 # Signup process
#                 sb.cdp.click('[href*="/u/signup/"]')
#                 sb.sleep(4)
# 
#                 _email = generate_email("gmail.com")
#                 sb.cdp.type("#email", _email)
#                 sb.sleep(4)
# 
#                 sb.cdp.click("button[type='submit']")
#                 sb.sleep(4)
# 
#                 _password = generate_password(20)
#                 sb.cdp.type("#password", _password)
#                 sb.sleep(10)
# 
#                 sb.cdp.click("button[type='submit']")
#                 sb.sleep(60)
# 
#                 sb.cdp.click("input[type='text']")
#                 sb.sleep(10)
# 
#                 api_key = pyperclip.paste()
# 
#                 # Store data
#                 data_list.append({
#                     'email': _email,
#                     'password': _password,
#                     'api_key': api_key,
#                     'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
#                 })
# 
#                 logging.info(f"Successfully completed iteration {i + 1}")
# 
#         except Exception as e:
#             logging.error(f"Error in iteration {i + 1}: {e}")
#             continue
# 
#         # Save after each successful iteration
#         save_to_excel(data_list)
# 
#         # Wait between iterations
#         if i < num_iterations - 1:
#             time.sleep(delay_between)
# 
# 
# if __name__ == "__main__":
#     try:
#         automate_signup()
#     except Exception as e:
#         logging.error(f"Main execution error: {e}")

import pyperclip
from seleniumbase import SB
from utils import generate_email, generate_password
import pandas as pd
from datetime import datetime
import time
import logging
from openpyxl import load_workbook
import os


def append_to_excel(data, filename='credentials.xlsx'):
    df = pd.DataFrame([data])
    if not os.path.exists(filename):
        df.to_excel(filename, index=False)
    else:
        with pd.ExcelWriter(filename, mode='a', engine='openpyxl', if_sheet_exists='overlay') as writer:
            book = load_workbook(filename)
            startrow = book.active.max_row
            df.to_excel(writer, index=False, header=False, startrow=startrow)


def automate_signup(num_iterations=5, delay_between=60):
    for i in range(num_iterations):
        try:
            with SB(uc=True, test=True, locale_code="en", ad_block=True) as sb:
                url = "https://app.tavily.com/home"
                sb.activate_cdp_mode(url)
                sb.sleep(20)

                sb.cdp.click('[href*="/u/signup/"]')
                _email = generate_email("gmail.com")
                sb.cdp.type("#email", _email)
                sb.sleep(4)

                sb.cdp.click("button[type='submit']")
                _password = generate_password(20)
                sb.cdp.type("#password", _password)
                sb.sleep(10)

                sb.cdp.click("button[type='submit']")
                sb.sleep(60)

                sb.cdp.click("input[type='text']")
                api_key = pyperclip.paste()

                data = {
                    'email': _email,
                    'password': _password,
                    'api_key': api_key,
                    'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
                append_to_excel(data)
                logging.info(f"Iteration {i + 1} completed")

            time.sleep(delay_between)

        except Exception as e:
            logging.error(f"Error in iteration {i + 1}: {e}")
            continue


if __name__ == "__main__":
    logging.basicConfig(filename='automation.log', level=logging.INFO)
    automate_signup()
